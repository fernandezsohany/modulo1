/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nombrecompañeross;

/**
 *
 * @author Keren Serrano
 */
public class Nombrecompañeross {

   public static void main(String[] args) {
        // Definición del arreglo de nombres
        String[] nombres = {
            "Axel",
            "Alejandra",
            "Bryan",
            "Dunia",
            "David",
            "Andrea",
            "Eduardo",
            "Yajaira",
            "Karla",
            "José"
        };

        // Impresión de los nombres
        for (int i = 0; i < nombres.length; i++) {
            System.out.println("Compañero " + (i + 1) + ": " + nombres[i]);
        }
    }
}
