/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package operacionesaritmeticas;

/**
 *
 * @author Keren Serrano
 */
public class Operacionesaritmeticas {
    public static void main(String[] args) {
     
        int num1 = 10;
        int num2 = 5;

        
        int suma = num1 + num2;
        System.out.println("Suma: " + num1 + " + " + num2 + " = " + suma);

     
        int resta = num1 - num2;
        System.out.println("Resta: " + num1 + " - " + num2 + " = " + resta);

        int multiplicacion = num1 * num2;
        System.out.println("Multiplicación: " + num1 + " * " + num2 + " = " + multiplicacion);

        if (num2 != 0) {
            int division = num1 / num2;
            System.out.println("División: " + num1 + " / " + num2 + " = " + division);
        } else {
            System.out.println("División: No se puede dividir por cero");
        }

        if (num2 != 0) {
            int modulo = num1 % num2;
            System.out.println("Módulo: " + num1 + " % " + num2 + " = " + modulo);
        } else {
            System.out.println("Módulo: No se puede dividir por cero");
        }
    }
}
