/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package evelucionexpreciones;

/**
 *
 * @author Keren Serrano
 */
public class Evelucionexpreciones {

  public static void main(String[] args) {
        // Declaración de las variables
        int M = 6;
        int T = 1;
        int K = -10;

        // Evaluación de las expresiones
        boolean expresion1 = M > T;
        boolean expresion2 = T / K == -5;
        boolean expresion3 = (M + T == 7) || (M - T == 5);

        // Impresión de los resultados
        System.out.println("M > T: " + expresion1);
        System.out.println("T / K == -5: " + expresion2);
        System.out.println("(M + T == 7) || (M - T == 5): " + expresion3);
    }
}
